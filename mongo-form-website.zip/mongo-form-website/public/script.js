const form = document.getElementById('contactForm');
const button = document.getElementById('submitBtn');
const statusBox = document.getElementById('formStatus');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  statusBox.textContent = '';
  statusBox.className = 'status';
  if (!form.reportValidity()) return;

  const formData = Object.fromEntries(new FormData(form).entries());
  button.disabled = true;
  button.innerHTML = 'Submitting...';

  try {
    const response = await fetch('/api/submissions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || 'Submission failed.');
    statusBox.textContent = result.message;
    statusBox.classList.add('success');
    form.reset();
  } catch (error) {
    statusBox.textContent = error.message || 'Unable to connect. Please try again.';
    statusBox.classList.add('error');
  } finally {
    button.disabled = false;
    button.innerHTML = 'Submit form <span aria-hidden="true">↗</span>';
  }
});
